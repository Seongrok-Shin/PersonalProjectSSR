/**

@author Seongrok
@version 1

*/
package toDoList;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class ToDoClass {
	private static List<String> currentList = new ArrayList<String>();
	
	public static void main(String[] args){
		
		int contents = -1;
		
		while(contents != 0){
			contents = content();
			switch(contents) {
			case 1:
				toShowList();
				break;
			case 2:
				addContent();
				break;
			case 3:
				removeContent();
				break;
			case 0:
				break;
			default:
				System.out.println("Enter a valid option");
			}
		}
	}
	
	public static int content() {
		Scanner scan = new Scanner(System.in);
		System.out.println();
        System.out.println("----------------------");
        System.out.println("Main Menu");
        System.out.println("----------------------");
        System.out.println("0. Exit the program");
        System.out.println("1. Display the list");
        System.out.println("2. Add content to the list");
        System.out.println("3. Remove content from the list");
        System.out.println();
        System.out.print("Enter the number: ");
        int number = scan.nextInt();
        return number;
	}
	
	public static void toShowList(){
        System.out.println();
        System.out.println("----------------------");       
        System.out.println("To-Do List");
        System.out.println("----------------------");
        
        int number = 0;
        
        for (String content : currentList) {
            System.out.println(++number + " " + content);
        }
        
        System.out.println("----------------------");
	}
	
    public static void addContent() {
        System.out.println("Add Content");
        System.out.println("----------------------");
        System.out.print("Enter a content: ");
        
        Scanner scan = new Scanner(System.in);
        String content = scan.nextLine();
        
        currentList.add(content);
        
        toShowList();
    }
    
    public static void removeContent() {
        System.out.println("Remove Content");
        System.out.println("----------------------");
        Scanner scan = new Scanner(System.in);
        System.out.print("What do you want to remove?");
        
        int index = scan.nextInt();
        
        if((index-1)<0 || index>currentList.size()) {
            System.out.println("Wrong index number! Please enter in range of 1 to "+currentList.size());            
        }
        else {
            currentList.remove(index-1);
        }
        
        System.out.println("----------------------");
        toShowList();
    }
}
